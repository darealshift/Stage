describe('less.js browser test - rootpath url\'s', function() {
    testLessEqualsInDocument();
});
